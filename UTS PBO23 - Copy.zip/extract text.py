from tkinter import Tk, Label, Button, Text, filedialog
from PIL import Image, ImageTk
import pytesseract

class ImageTextExtractor:
    def __init__(self, root):
        self.root = root
        self.root.title("Aplikasi Ekstraksi Teks dari Gambar")

        self.image_label = Label(root, text="Gambar belum dipilih")
        self.image_label.pack(pady=10)

        self.browse_button = Button(root, text="Pilih Gambar", command=self.browse_image)
        self.browse_button.pack(pady=10)

        self.extract_button = Button(root, text="Ekstrak Teks", command=self.extract_text)
        self.extract_button.pack(pady=10)

        self.text_output = Text(root, height=10, width=50)
        self.text_output.pack(pady=10)

    def browse_image(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.png;*.jpg;*.jpeg;*.gif")])
        if file_path:
            self.image = Image.open(file_path)
            self.image_label.config(text=f"Gambar: {file_path}")
            self.image.thumbnail((300, 300))
            self.tk_image = ImageTk.PhotoImage(self.image)
            self.image_label.config(image=self.tk_image)
            self.image_label.image = self.tk_image

    def extract_text(self):
        if hasattr(self, 'image'):
            text = pytesseract.image_to_string(self.image)
            self.text_output.delete(1.0, "end")
            self.text_output.insert("end", text)
        else:
            self.text_output.delete(1.0, "end")
            self.text_output.insert("end", "Pilih gambar terlebih dahulu.")

if __name__ == "__main__":
    root = Tk()
    app = ImageTextExtractor(root)
    root.mainloop()
